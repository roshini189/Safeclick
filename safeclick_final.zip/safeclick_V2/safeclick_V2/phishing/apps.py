from django.apps import AppConfig


class PhishingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'phishing'
