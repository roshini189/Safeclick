from django.shortcuts import render
from django.http import JsonResponse
import logging
import joblib
import pandas as pd
from .feature_extraction import extract_features

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load the trained model
model = joblib.load('custom_gradient_booting_model_5.pkl')
logger.debug("Model loaded successfully.")
# Home view
def home(request):
    prediction_text = None
    if request.method == 'POST':
        url = request.POST.get('url')  # Get the user-input URL
        result = predict_url_safety(url)  # Use the helper function
        if 'error' in result:
            prediction_text = result['error']
        else:
            prediction_text = "Safe" if result['is_safe'] else "Unsafe"
    return render(request, 'phishing/index.html', {'prediction': prediction_text})

# API endpoint for URL classification
def classify_url(request):
    url = request.GET.get('url')  # Get URL from query parameters
    if not url:
        return JsonResponse({'error': "URL is required"}, status=400)

    result = predict_url_safety(url)  # Use the helper function
    if 'error' in result:
        return JsonResponse({'error': result['error']}, status=500)
    
    insights = generate_insights(result['features'], result['is_safe'])

    return JsonResponse({
        'is_safe': bool(result['is_safe']),
        'insights': insights,
        'features': result.get('features')
    })

# Helper function for classification
def predict_url_safety(url):
    logger.debug(f"Extracting features for URL: {url}")

    if not url:
        return {'error': "URL is required", 'is_safe': None}

    try:
        extracted_features = extract_features(url)
        logger.debug(f"Extracted Features: {extracted_features}")  # Log the features

        # Align extracted features with model input
        expected_features = ['NumDots', 'SubdomainLevel', 'PathLevel', 'UrlLength', 'NumDash', 'NumDashInHostname',
                             'NumUnderscore', 'NumPercent', 'NumQueryComponents', 'NumAmpersand', 'NumNumericChars',
                             'NoHttps', 'RandomString', 'IpAddress', 'DomainInPaths', 'HostnameLength', 'PathLength',
                             'QueryLength', 'NumSensitiveWords', 'EmbeddedBrandName', 'PctExtHyperlinks', 'PctExtResourceUrls',
                             'ExtFavicon', 'InsecureForms', 'RelativeFormAction', 'ExtFormAction', 'PctNullSelfRedirectHyperlinks',
                             'FrequentDomainNameMismatch', 'SubmitInfoToEmail', 'IframeOrFrame', 'MissingTitle', 'SubdomainLevelRT',
                             'UrlLengthRT', 'PctExtResourceUrlsRT', 'AbnormalExtFormActionR', 'ExtMetaScriptLinkRT',
                             'PctExtNullSelfRedirectHyperlinksRT']

        # Ensure the features match the expected order
        aligned_features = {feature: extracted_features.get(feature, 0) for feature in expected_features}
        aligned_features_df = pd.DataFrame([aligned_features])
        logger.debug(f"DataFrame for Prediction: {aligned_features_df}")  # Log the DataFrame

        prediction = model.predict(aligned_features_df)[0]
        is_safe = prediction == 1  # If 1, it's safe; if 0, it's unsafe
        logger.debug(f"Prediction: {is_safe}")

        return {'is_safe': is_safe, 'features': aligned_features}
    
    except Exception as e:
        logger.error(f"Error during classification: {str(e)}")
        return {'error': "Unable to classify the URL. Please try again later.", 'is_safe': None}

# Helper function to generate insights
def generate_insights(features, is_safe):
    report = create_human_readable_report(features, is_safe)  # Generate user-friendly explanations

    best_practices = []
    if not is_safe:
        best_practices = [
            "Avoid URLs without HTTPS.",
            "Be cautious of domains with high numbers of dots or random strings.",
            "Verify the legitimacy of the sender or website."
        ]

    return {
        'user_friendly_report': report,
        'best_practices': best_practices
    }

# Helper function to create a human-readable report
def create_human_readable_report(features, is_safe):
    report = []
    if not is_safe:
        if features.get('NoHttps', 0) == 1:
            report.append("The URL does not use HTTPS, indicating it might be insecure.")
        if features.get('NumDots', 0) > 3:
            report.append("The domain contains a high number of dots, which is a common trait of phishing URLs.")
        if features.get('SubdomainLevel', 0) > 2:
            report.append("The URL has too many subdomains, often used to mask malicious intentions.")
        if features.get('PathLevel', 0) > 3:
            report.append("The URL has a deep path structure, which can be a sign of phishing.")
        if features.get('UrlLength', 0) > 75:
            report.append("The URL is unusually long, which might indicate a phishing attempt.")
        if features.get('NumDash', 0) > 2:
            report.append("The URL contains multiple dashes, which are commonly used in phishing URLs.")
        if features.get('NumDashInHostname', 0) > 1:
            report.append("The hostname contains multiple dashes, which is unusual for legitimate domains.")
        if features.get('NumUnderscore', 0) > 0:
            report.append("The URL contains underscores, which are uncommon in legitimate URLs.")
        if features.get('NumPercent', 0) > 0:
            report.append("The URL contains percentage symbols (%), which can be used for obfuscation.")
        if features.get('NumQueryComponents', 0) > 2:
            report.append("The URL has too many query parameters, which may indicate phishing.")
        if features.get('NumAmpersand', 0) > 1:
            report.append("The URL contains multiple ampersands (&), often used in phishing URLs.")
        if features.get('NumNumericChars', 0) > 10:
            report.append("The URL contains a high number of numeric characters, which is unusual.")
        if features.get('RandomString', 0) == 1:
            report.append("The URL contains random strings, which are often seen in phishing attempts.")
        if features.get('IpAddress', 0) == 1:
            report.append("The URL uses an IP address in the hostname, which is a common phishing indicator.")
        if features.get('DomainInPaths', 0) == 1:
            report.append("The URL includes domain names in its paths, which can indicate phishing.")
        if features.get('HostnameLength', 0) > 50:
            report.append("The hostname is unusually long, which is a red flag.")
        if features.get('PathLength', 0) > 50:
            report.append("The path is unusually long, indicating potential phishing.")
        if features.get('QueryLength', 0) > 100:
            report.append("The query string is excessively long, which is a potential red flag.")
        if features.get('NumSensitiveWords', 0) > 0:
            report.append("The URL contains sensitive words like 'login' or 'secure,' often used in phishing.")
        if features.get('EmbeddedBrandName', 0) == 1:
            report.append("The URL embeds brand names deceptively, which is a common phishing technique.")
        # Add other checks for features...

    else:
        report.append("No suspicious characteristics detected in this URL. It appears to be safe.")

    return report
